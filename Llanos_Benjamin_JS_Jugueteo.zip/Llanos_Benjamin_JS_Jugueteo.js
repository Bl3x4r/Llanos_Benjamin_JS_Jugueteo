var alturaNiño = 87;

function puedeSubir(){
    if(alturaNiño > 52 ){
        console.log("!Subete Chico¡");
    }else{
        console.log("Lo siento,chico.Tal vez el proximo año.");
    }
}
puedeSubir(alturaNiño);